import { useEffect, useRef, useState, useCallback } from "react";
import { Link } from "@tanstack/react-router";

const TOTAL_PHASES = 10;
export const COINS_KEY = "salveplaneta:coins";
const PHASE_KEY = "salveplaneta:phase";

function phaseConfig(idx: number) {
  const goal = 8 + idx * 2;
  const baseSpeed = 90 + idx * 30;
  const spawnEvery = Math.max(0.4, 1.15 - idx * 0.07);
  const badRate = Math.min(0.45, 0.18 + idx * 0.03);
  const time = 40;
  const reward = 3 + idx;
  return { goal, baseSpeed, spawnEvery, badRate, time, reward };
}

const GOOD_EMOJIS = ["♻️", "🥤", "📦", "🍾", "🥫", "📰", "💧", "🌱", "🍃"];
const BAD_EMOJIS = ["🏭", "☠️", "🛢️", "☣️", "🔥"];

type Entity = { id: number; x: number; y: number; r: number; vx: number; kind: "good" | "bad"; emoji: string };

export function SalveOPlanetaGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [phaseIdx, setPhaseIdx] = useState(() => {
    if (typeof window === "undefined") return 0;
    return Math.min(TOTAL_PHASES - 1, Math.max(0, Number(localStorage.getItem(PHASE_KEY) ?? 0)));
  });
  const [coins, setCoins] = useState(() => {
    if (typeof window === "undefined") return 0;
    return Number(localStorage.getItem(COINS_KEY) ?? 0);
  });
  const [lives, setLives] = useState(3);
  const [phaseScore, setPhaseScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(phaseConfig(0).time);
  const [status, setStatus] = useState<"playing" | "won" | "lost" | "victory">("playing");
  const [paused, setPaused] = useState(false);

  const entitiesRef = useRef<Entity[]>([]);
  const idRef = useRef(0);
  const lastSpawnRef = useRef(0);
  const rafRef = useRef<number | null>(null);
  const sizeRef = useRef({ w: 900, h: 520 });
  const hitFlashRef = useRef(0);
  const elapsedRef = useRef(0);

  const playerY = useRef(260);
  const keysRef = useRef({ up: false, down: false });
  const touchTargetRef = useRef<number | null>(null);

  const cfg = phaseConfig(phaseIdx);

  useEffect(() => {
    localStorage.setItem(COINS_KEY, String(coins));
    window.dispatchEvent(new CustomEvent("salveplaneta:coins", { detail: coins }));
  }, [coins]);
  useEffect(() => { localStorage.setItem(PHASE_KEY, String(phaseIdx)); }, [phaseIdx]);

  const startPhase = useCallback((idx: number) => {
    const clamped = Math.max(0, Math.min(TOTAL_PHASES - 1, idx));
    setPhaseIdx(clamped);
    setPhaseScore(0);
    setTimeLeft(phaseConfig(clamped).time);
    setLives(3);
    entitiesRef.current = [];
    playerY.current = sizeRef.current.h / 2;
    elapsedRef.current = 0;
    setPaused(false);
    setStatus("playing");
  }, []);

  useEffect(() => {
    const onResize = () => {
      const el = containerRef.current;
      const c = canvasRef.current;
      if (!el || !c) return;
      const w = el.clientWidth;
      const h = Math.max(380, Math.min(620, Math.round(w * 0.55)));
      sizeRef.current = { w, h };
      const dpr = window.devicePixelRatio || 1;
      c.width = w * dpr;
      c.height = h * dpr;
      c.style.width = w + "px";
      c.style.height = h + "px";
      const ctx = c.getContext("2d");
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      playerY.current = Math.min(playerY.current, h - 60);
    };
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (["ArrowUp", "w", "W"].includes(e.key)) { keysRef.current.up = true; e.preventDefault(); }
      if (["ArrowDown", "s", "S"].includes(e.key)) { keysRef.current.down = true; e.preventDefault(); }
    };
    const up = (e: KeyboardEvent) => {
      if (["ArrowUp", "w", "W"].includes(e.key)) keysRef.current.up = false;
      if (["ArrowDown", "s", "S"].includes(e.key)) keysRef.current.down = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useEffect(() => {
    if (status !== "playing" || paused) return;
    const t = setInterval(() => setTimeLeft((s) => (s <= 1 ? 0 : s - 1)), 1000);
    return () => clearInterval(t);
  }, [status, phaseIdx, paused]);

  useEffect(() => {
    if (status !== "playing") return;
    if (lives <= 0) { setStatus("lost"); return; }
    if (phaseScore >= cfg.goal) {
      setCoins((c) => c + cfg.reward);
      setStatus(phaseIdx + 1 >= TOTAL_PHASES ? "victory" : "won");
    } else if (timeLeft === 0) {
      setStatus("lost");
    }
  }, [phaseScore, timeLeft, lives, status, cfg.goal, cfg.reward, phaseIdx]);

  const drawScene = (ctx: CanvasRenderingContext2D, w: number, h: number, time: number) => {
    const sky = ctx.createLinearGradient(0, 0, 0, h * 0.65);
    sky.addColorStop(0, "#7dd3fc");
    sky.addColorStop(1, "#bae6fd");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h * 0.65);

    const sunX = w - 90, sunY = 80;
    const grad = ctx.createRadialGradient(sunX, sunY, 5, sunX, sunY, 90);
    grad.addColorStop(0, "rgba(253,224,71,0.9)");
    grad.addColorStop(1, "rgba(253,224,71,0)");
    ctx.fillStyle = grad;
    ctx.fillRect(sunX - 100, sunY - 100, 200, 200);
    ctx.beginPath();
    ctx.fillStyle = "#fde047";
    ctx.arc(sunX, sunY, 35, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#6b7280";
    drawMountain(ctx, w * 0.15, h * 0.65, 280, 220);
    drawMountain(ctx, w * 0.55, h * 0.65, 320, 260);
    drawMountain(ctx, w * 0.85, h * 0.65, 260, 200);

    ctx.fillStyle = "#4ade80";
    ctx.fillRect(0, h * 0.65, w, h * 0.35);
    ctx.fillStyle = "#22c55e";
    ctx.fillRect(0, h * 0.65, w, 8);

    ctx.fillStyle = "#38bdf8";
    ctx.beginPath();
    ctx.moveTo(0, h * 0.86);
    ctx.quadraticCurveTo(w * 0.5, h * 0.82, w, h * 0.88);
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();

    const cx = ((time * 0.02) % (w + 200)) - 100;
    drawCloud(ctx, cx, 70, 1);
    drawCloud(ctx, (cx + w * 0.6) % (w + 200) - 100, 110, 0.8);

    const treeY = h * 0.7;
    const count = Math.ceil(w / 90);
    for (let i = 0; i < count; i++) drawTree(ctx, i * 90 + 45, treeY);
  };

  const drawMountain = (ctx: CanvasRenderingContext2D, cx: number, by: number, hw: number, hh: number) => {
    ctx.beginPath();
    ctx.moveTo(cx - hw / 2, by);
    ctx.lineTo(cx, by - hh);
    ctx.lineTo(cx + hw / 2, by);
    ctx.closePath();
    ctx.fill();
  };
  const drawCloud = (ctx: CanvasRenderingContext2D, x: number, y: number, s: number) => {
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(x, y, 22 * s, 0, Math.PI * 2);
    ctx.arc(x + 25 * s, y - 8 * s, 26 * s, 0, Math.PI * 2);
    ctx.arc(x + 55 * s, y, 22 * s, 0, Math.PI * 2);
    ctx.arc(x + 30 * s, y + 10 * s, 24 * s, 0, Math.PI * 2);
    ctx.fill();
  };
  const drawTree = (ctx: CanvasRenderingContext2D, x: number, y: number) => {
    ctx.fillStyle = "#7c3a1d";
    ctx.fillRect(x - 5, y, 10, 40);
    ctx.fillStyle = "#15803d";
    ctx.beginPath();
    ctx.arc(x, y - 5, 28, 0, Math.PI * 2);
    ctx.fill();
  };
  const drawPlayer = (ctx: CanvasRenderingContext2D, x: number, y: number, time: number) => {
    const bob = Math.sin(time * 0.006) * 2;
    ctx.save();
    ctx.translate(x, y + bob);
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.beginPath();
    ctx.ellipse(0, 42, 32, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    const grad = ctx.createRadialGradient(0, 0, 4, 0, 0, 40);
    grad.addColorStop(0, "#ffffff");
    grad.addColorStop(1, "#fde68a");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, 38, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = "#15803d";
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.font = "56px serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("🦸", 0, 2);
    ctx.restore();
  };

  useEffect(() => {
    if (status !== "playing" || paused) return;
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    let prev = performance.now();

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - prev) / 1000);
      prev = now;
      elapsedRef.current += dt * 1000;
      const elapsed = elapsedRef.current;
      const { w, h } = sizeRef.current;

      const speed = 340;
      if (touchTargetRef.current != null) {
        const target = touchTargetRef.current;
        const dy = target - playerY.current;
        playerY.current += Math.sign(dy) * Math.min(Math.abs(dy), speed * dt);
      } else {
        if (keysRef.current.up) playerY.current -= speed * dt;
        if (keysRef.current.down) playerY.current += speed * dt;
      }
      playerY.current = Math.max(50, Math.min(h - 50, playerY.current));

      // ramp up: speed and spawn rate increase over the phase duration
      const ramp = Math.min(1.6, 1 + (elapsed / 1000) / 25); // up to +60% after ~15s
      const curSpawnEvery = Math.max(0.25, cfg.spawnEvery / ramp);
      const curBaseSpeed = cfg.baseSpeed * ramp;

      lastSpawnRef.current += dt;
      if (lastSpawnRef.current > curSpawnEvery) {
        lastSpawnRef.current = 0;
        const isBad = Math.random() < cfg.badRate;
        const emojis = isBad ? BAD_EMOJIS : GOOD_EMOJIS;
        const vx = -(curBaseSpeed + Math.random() * 60);
        entitiesRef.current.push({
          id: idRef.current++,
          x: w + 30,
          y: 60 + Math.random() * (h - 120),
          r: 24,
          vx,
          kind: isBad ? "bad" : "good",
          emoji: emojis[Math.floor(Math.random() * emojis.length)],
        });
      }

      const px = 90;
      const py = playerY.current;
      const remaining: Entity[] = [];
      for (const e of entitiesRef.current) {
        e.x += e.vx * dt;
        if (e.x < -40) continue;
        const dx = e.x - px;
        const dy = e.y - py;
        if (Math.abs(dx) < e.r + 36 && Math.abs(dy) < e.r + 36) {
          if (e.kind === "good") {
            setPhaseScore((s) => s + 1);
            setCoins((c) => c + 1);
          } else {
            setLives((l) => l - 1);
            hitFlashRef.current = 0.4;
          }
          continue;
        }
        remaining.push(e);
      }
      entitiesRef.current = remaining;

      drawScene(ctx, w, h, elapsed);

      ctx.font = "40px serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      entitiesRef.current.forEach((e) => {
        ctx.save();
        ctx.shadowColor = "rgba(0,0,0,0.35)";
        ctx.shadowBlur = 6;
        ctx.fillText(e.emoji, e.x, e.y);
        ctx.restore();
      });

      drawPlayer(ctx, px, py, elapsed);

      if (hitFlashRef.current > 0) {
        ctx.save();
        ctx.fillStyle = `rgba(239,68,68,${Math.min(0.5, hitFlashRef.current)})`;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
        hitFlashRef.current = Math.max(0, hitFlashRef.current - dt);
      }

      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [status, paused, cfg.baseSpeed, cfg.spawnEvery, cfg.badRate]);

  const handlePointer = (ev: React.PointerEvent<HTMLCanvasElement>) => {
    if (status !== "playing") return;
    const rect = ev.currentTarget.getBoundingClientRect();
    touchTargetRef.current = ev.clientY - rect.top;
  };
  const clearPointer = () => { touchTargetRef.current = null; };

  return (
    <main className="min-h-screen bg-slate-900 p-3 md:p-6">
      <div ref={containerRef} className="relative max-w-5xl mx-auto rounded-2xl overflow-hidden shadow-2xl border-4 border-slate-800">
        <div className="absolute top-0 left-0 right-0 z-20 flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-gradient-to-b from-black/55 to-transparent">
          <div className="flex flex-wrap gap-2 items-center">
            <span className="hud-pill">🪙 {coins}</span>
            <span className="text-white/80 font-bold">|</span>
            <span className="hud-pill">❤️ {lives}</span>
            <span className="text-white/80 font-bold">|</span>
            <span className="hud-pill">⏰ {timeLeft}s</span>
            <span className="text-white/80 font-bold">|</span>
            <span className="hud-pill">🚀 Fase {phaseIdx + 1}/{TOTAL_PHASES}</span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setPaused((p) => !p)}
              className="text-xs md:text-sm bg-amber-400 hover:bg-amber-500 text-slate-900 font-bold px-3 py-1.5 rounded-full shadow"
            >
              {paused ? "▶ Continuar" : "⏸ Pausar"}
            </button>
            <Link to="/jardim" className="text-xs md:text-sm bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-3 py-1.5 rounded-full shadow">🌳 Jardim</Link>
            <Link to="/" className="text-xs md:text-sm bg-white/90 hover:bg-white text-slate-800 font-bold px-3 py-1.5 rounded-full shadow">← Menu</Link>
          </div>
        </div>

        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 bg-white/90 backdrop-blur px-4 py-1.5 rounded-full shadow font-bold text-sm text-emerald-900">
          🎯 Meta: {phaseScore}/{cfg.goal} — ⬆️⬇️ ou toque para mover
        </div>

        <canvas
          ref={canvasRef}
          onPointerDown={handlePointer}
          onPointerMove={handlePointer}
          onPointerUp={clearPointer}
          onPointerLeave={clearPointer}
          className="block w-full cursor-pointer touch-none select-none"
        />

        {paused && status === "playing" && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/55 p-4">
            <div className="bg-white rounded-2xl p-6 text-center shadow-2xl border-4 border-amber-400">
              <h2 className="text-2xl font-extrabold mb-3 text-amber-600">⏸ Pausado</h2>
              <button onClick={() => setPaused(false)} className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3 rounded-full shadow-lg">
                ▶ Continuar
              </button>
            </div>
          </div>
        )}

        {status !== "playing" && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/60 p-4">
            <div className="bg-white rounded-2xl p-6 md:p-8 max-w-md text-center shadow-2xl border-4 border-emerald-500">
              {status === "won" && (
                <>
                  <h2 className="text-2xl font-extrabold mb-2 text-emerald-700">✅ Fase {phaseIdx + 1} concluída!</h2>
                  <p className="mb-4 text-slate-700">Você ganhou <b>🪙 {cfg.reward} moedas</b>!<br/>Total: <b>{coins}</b></p>
                  <button onClick={() => startPhase(phaseIdx + 1)} className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3 rounded-full shadow-lg">
                    Fase {phaseIdx + 2} →
                  </button>
                </>
              )}
              {status === "lost" && (
                <>
                  <h2 className="text-2xl font-extrabold mb-2 text-red-600">⛔ Game Over</h2>
                  <p className="mb-4 text-slate-700">
                    {lives <= 0 ? "Você perdeu todas as vidas!" : "Tempo esgotado!"}<br/>
                    {phaseIdx > 0 ? <>Você voltou para a <b>Fase {phaseIdx}</b>.</> : <>Tente a <b>Fase 1</b> novamente.</>}
                  </p>
                  <button onClick={() => startPhase(Math.max(0, phaseIdx - 1))} className="bg-orange-600 hover:bg-orange-700 text-white font-bold px-6 py-3 rounded-full shadow-lg">
                    🔄 Tentar novamente
                  </button>
                </>
              )}
              {status === "victory" && (
                <>
                  <h2 className="text-2xl font-extrabold mb-2 text-emerald-700">🏆 Planeta salvo!</h2>
                  <p className="mb-4 text-slate-700">Você completou as {TOTAL_PHASES} fases!<br/>Moedas: <b>🪙 {coins}</b></p>
                  <div className="flex gap-2 justify-center flex-wrap">
                    <button onClick={() => startPhase(0)} className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3 rounded-full shadow-lg">🔁 Jogar de novo</button>
                    <Link to="/jardim" className="bg-lime-600 hover:bg-lime-700 text-white font-bold px-6 py-3 rounded-full shadow-lg">🌳 Ir ao Jardim</Link>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      <p className="text-center text-white/70 text-xs mt-3">
        Use ⬆️ ⬇️ (ou W/S) — no celular, toque e arraste para mover o herói.
      </p>
    </main>
  );
}