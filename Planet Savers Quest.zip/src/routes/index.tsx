import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Salve o Planeta — Como Jogar" },
      { name: "description", content: "Aprenda a jogar Salve o Planeta: recicle, apague queimadas, economize água e plante árvores." },
      { property: "og:title", content: "Salve o Planeta — Como Jogar" },
      { property: "og:description", content: "Jogo educativo sobre meio ambiente." },
    ],
  }),
  component: HowToPlay,
});

function HowToPlay() {
  return (
    <main className="min-h-screen scene-bg relative overflow-hidden">
      <SceneDecor />
      <div className="relative z-10 max-w-4xl mx-auto px-6 py-12 md:py-16">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-extrabold text-white drop-shadow-[0_4px_0_rgba(0,0,0,0.35)] tracking-tight">
            🌍 Salve o Planeta
          </h1>
          <p className="mt-3 text-lg md:text-xl text-white/95 drop-shadow font-semibold">
            Um jogo sobre cuidar do nosso mundo 🌱
          </p>
        </div>

        <div className="bg-white/95 backdrop-blur rounded-3xl shadow-2xl p-6 md:p-8 border-4 border-emerald-700/30">
          <h2 className="text-2xl md:text-3xl font-bold text-emerald-800 mb-4 flex items-center gap-2">
            🎮 Como jogar
          </h2>
          <ul className="space-y-3 text-base md:text-lg text-slate-700">
            <li className="flex gap-3"><span className="text-2xl">🦸</span><span>Seu herói fica fixo na <b>esquerda</b> — mova-o só para <b>cima e baixo</b>.</span></li>
            <li className="flex gap-3"><span className="text-2xl">⬆️⬇️</span><span>Use as <b>setas</b> ou <b>W/S</b> (no celular, toque e arraste).</span></li>
            <li className="flex gap-3"><span className="text-2xl">♻️</span><span>Colete os itens <b>bons</b> (recicláveis, água, mudas) que vêm da direita.</span></li>
            <li className="flex gap-3"><span className="text-2xl">☠️</span><span>Desvie dos vilões (🏭 🛢️ 🔥) — eles tiram <b>vida</b>!</span></li>
            <li className="flex gap-3"><span className="text-2xl">🚀</span><span>São <b>10 fases</b>, cada uma mais rápida que a anterior.</span></li>
            <li className="flex gap-3"><span className="text-2xl">🪙</span><span>Ao vencer, ganhe <b>moedas</b>. Ao perder, volta uma fase.</span></li>
            <li className="flex gap-3"><span className="text-2xl">🌳</span><span>Use as moedas no <b>Jardim</b> para plantar árvores!</span></li>
          </ul>

          <div className="grid md:grid-cols-2 gap-4 mt-6">
            <div className="rounded-2xl bg-emerald-50 border-2 border-emerald-300 p-4">
              <h3 className="font-extrabold text-emerald-800 mb-2 text-lg">✅ Pode pegar (+1 ponto e +1 🪙)</h3>
              <div className="flex flex-wrap gap-2 text-3xl">
                <span title="Reciclagem">♻️</span>
                <span title="Copo">🥤</span>
                <span title="Caixa">📦</span>
                <span title="Garrafa">🍾</span>
                <span title="Lata">🥫</span>
                <span title="Papel/Jornal">📰</span>
                <span title="Água">💧</span>
                <span title="Muda">🌱</span>
                <span title="Folha">🍃</span>
              </div>
              <p className="text-xs text-slate-600 mt-2">Recicláveis, papel, água e plantas.</p>
            </div>
            <div className="rounded-2xl bg-red-50 border-2 border-red-300 p-4">
              <h3 className="font-extrabold text-red-700 mb-2 text-lg">⛔ NÃO pegue (−1 vida)</h3>
              <div className="flex flex-wrap gap-2 text-3xl">
                <span title="Fábrica">🏭</span>
                <span title="Veneno">☠️</span>
                <span title="Petróleo">🛢️</span>
                <span title="Tóxico">☣️</span>
                <span title="Fogo / Queimada">🔥</span>
              </div>
              <p className="text-xs text-slate-600 mt-2">Fábrica, petróleo e fogo tiram vida!</p>
            </div>
          </div>

          <div className="mt-7 flex justify-center gap-3 flex-wrap">
            <Link
              to="/jogar"
              className="inline-flex items-center gap-2 bg-gradient-to-b from-emerald-500 to-emerald-700 hover:from-emerald-400 hover:to-emerald-600 text-white font-extrabold text-xl px-8 py-4 rounded-full shadow-[0_6px_0_rgba(0,0,0,0.25)] active:translate-y-1 active:shadow-[0_2px_0_rgba(0,0,0,0.25)] transition border-4 border-white/40"
            >
              ▶ Começar a jogar
            </Link>
            <Link
              to="/jardim"
              className="inline-flex items-center gap-2 bg-gradient-to-b from-lime-500 to-lime-700 hover:from-lime-400 hover:to-lime-600 text-white font-extrabold text-xl px-8 py-4 rounded-full shadow-[0_6px_0_rgba(0,0,0,0.25)] active:translate-y-1 active:shadow-[0_2px_0_rgba(0,0,0,0.25)] transition border-4 border-white/40"
            >
              🌳 Meu Jardim
            </Link>
          </div>
        </div>

        <p className="text-center text-white/90 mt-6 text-sm drop-shadow font-semibold">
          Feito com 💚 — Canvas API + JavaScript
        </p>
      </div>
    </main>
  );
}

function SceneDecor() {
  return (
    <>
      <div className="absolute top-6 right-10 w-28 h-28 rounded-full bg-yellow-300 shadow-[0_0_80px_40px_rgba(253,224,71,0.55)] z-0" />
      <div className="absolute top-16 left-10 text-white text-7xl opacity-90 select-none">☁️</div>
      <div className="absolute top-28 left-1/2 text-white text-6xl opacity-90 select-none">☁️</div>
      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-b from-emerald-500 to-emerald-700" />
      <div className="absolute bottom-0 left-0 right-0 flex justify-around text-5xl md:text-6xl pb-3 select-none">
        <span>🌳</span><span>🌲</span><span>🌳</span><span>🌲</span><span>🌳</span><span>🌲</span><span>🌳</span>
      </div>
    </>
  );
}