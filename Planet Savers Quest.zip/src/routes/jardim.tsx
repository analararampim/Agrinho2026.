import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";

const COINS_KEY = "salveplaneta:coins";
const TREES_KEY = "salveplaneta:trees";
const TREE_COST = 5;

type Spot = { id: string; name: string; emoji: string; slots: number; bg: string };
type Tier = { id: string; name: string; subtitle: string; icon: string; spots: Spot[] };

const TIERS: Tier[] = [
  {
    id: "cidade",
    name: "Cidades",
    subtitle: "Comece reverdecendo a cidade",
    icon: "🏙️",
    spots: [
      { id: "parque", name: "Parque da Cidade", emoji: "🏞️", slots: 6, bg: "from-emerald-100 to-emerald-200" },
      { id: "escola", name: "Escola", emoji: "🏫", slots: 5, bg: "from-sky-100 to-emerald-200" },
      { id: "rua", name: "Rua Verde", emoji: "🏘️", slots: 6, bg: "from-stone-100 to-emerald-200" },
      { id: "praca", name: "Praça Central", emoji: "⛲", slots: 5, bg: "from-cyan-100 to-emerald-200" },
    ],
  },
  {
    id: "fazenda",
    name: "Fazendas queimadas",
    subtitle: "Recupere áreas devastadas por queimadas",
    icon: "🔥",
    spots: [
      { id: "pasto", name: "Pasto Queimado", emoji: "🐄", slots: 7, bg: "from-orange-100 to-emerald-200" },
      { id: "cafezal", name: "Cafezal", emoji: "☕", slots: 6, bg: "from-amber-100 to-emerald-200" },
      { id: "campo", name: "Campo Aberto", emoji: "🌾", slots: 8, bg: "from-yellow-100 to-emerald-200" },
    ],
  },
  {
    id: "amazonia",
    name: "Floresta Amazônica",
    subtitle: "Reflorestamento de mata nativa",
    icon: "🌳",
    spots: [
      { id: "igarape", name: "Margem do Igarapé", emoji: "🐊", slots: 8, bg: "from-teal-100 to-emerald-300" },
      { id: "mata", name: "Mata Densa", emoji: "🦜", slots: 10, bg: "from-green-200 to-emerald-400" },
      { id: "clareira", name: "Clareira Desmatada", emoji: "🪵", slots: 9, bg: "from-lime-100 to-emerald-300" },
    ],
  },
  {
    id: "mundo",
    name: "Mundo",
    subtitle: "Reflorestamento global",
    icon: "🌍",
    spots: [
      { id: "savana", name: "Savana Africana", emoji: "🦒", slots: 8, bg: "from-yellow-200 to-emerald-300" },
      { id: "ártico", name: "Tundra do Norte", emoji: "🦊", slots: 6, bg: "from-sky-200 to-emerald-200" },
      { id: "ilha", name: "Ilha Tropical", emoji: "🏝️", slots: 7, bg: "from-cyan-200 to-emerald-300" },
      { id: "montanha", name: "Encosta da Montanha", emoji: "⛰️", slots: 8, bg: "from-stone-200 to-emerald-300" },
    ],
  },
];

type TreesState = Record<string, number>;

export const Route = createFileRoute("/jardim")({
  head: () => ({
    meta: [
      { title: "Salve o Planeta — Jardim" },
      { name: "description", content: "Use suas moedas para plantar árvores em diferentes lugares." },
    ],
  }),
  component: Jardim,
});

function Jardim() {
  const [coins, setCoins] = useState<number>(() => {
    if (typeof window === "undefined") return 0;
    return Number(localStorage.getItem(COINS_KEY) ?? 0);
  });
  const [trees, setTrees] = useState<TreesState>(() => {
    if (typeof window === "undefined") return {};
    try { return JSON.parse(localStorage.getItem(TREES_KEY) || "{}"); } catch { return {}; }
  });
  const [pulse, setPulse] = useState<string | null>(null);
  const [confetti, setConfetti] = useState<Array<{ id: number; x: number; y: number; emoji: string }>>([]);

  useEffect(() => {
    const sync = () => setCoins(Number(localStorage.getItem(COINS_KEY) ?? 0));
    sync();
    const onCustom = (e: Event) => {
      const ce = e as CustomEvent<number>;
      if (typeof ce.detail === "number") setCoins(ce.detail);
      else sync();
    };
    window.addEventListener("salveplaneta:coins", onCustom);
    window.addEventListener("storage", sync);
    window.addEventListener("focus", sync);
    return () => {
      window.removeEventListener("salveplaneta:coins", onCustom);
      window.removeEventListener("storage", sync);
      window.removeEventListener("focus", sync);
    };
  }, []);

  useEffect(() => { localStorage.setItem(COINS_KEY, String(coins)); }, [coins]);
  useEffect(() => { localStorage.setItem(TREES_KEY, JSON.stringify(trees)); }, [trees]);

  const tierCompleted = (tier: Tier) =>
    tier.spots.every((s) => (trees[s.id] ?? 0) >= s.slots);

  const activeTierIdx = useMemo(() => {
    const i = TIERS.findIndex((t) => !tierCompleted(t));
    return i === -1 ? TIERS.length - 1 : i;
  }, [trees]);

  const plant = (tierIdx: number, id: string, max: number, ev: React.MouseEvent) => {
    if (coins < TREE_COST) return;
    if (tierIdx > activeTierIdx) return;
    if ((trees[id] ?? 0) >= max) return;
    setCoins((c) => c - TREE_COST);
    setTrees((t) => ({ ...t, [id]: (t[id] ?? 0) + 1 }));
    setPulse(id);
    setTimeout(() => setPulse((p) => (p === id ? null : p)), 700);
    const rect = (ev.currentTarget as HTMLElement).getBoundingClientRect();
    const cx = ev.clientX - rect.left;
    const cy = ev.clientY - rect.top;
    const pieces = ["🌿", "🍃", "✨", "🌱", "💚"];
    const burst = Array.from({ length: 7 }).map((_, k) => ({
      id: Date.now() + k,
      x: cx + (Math.random() - 0.5) * 40,
      y: cy + (Math.random() - 0.5) * 20,
      emoji: pieces[Math.floor(Math.random() * pieces.length)],
    }));
    setConfetti((c) => [...c, ...burst]);
    setTimeout(() => {
      setConfetti((c) => c.filter((p) => !burst.find((b) => b.id === p.id)));
    }, 900);
  };

  const totalTrees = Object.values(trees).reduce((a, b) => a + b, 0);

  return (
    <main className="min-h-screen bg-gradient-to-b from-sky-300 via-emerald-300 to-emerald-600 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
          <h1 className="text-3xl md:text-5xl font-extrabold text-white drop-shadow-[0_3px_0_rgba(0,0,0,0.35)]">
            🌳 Meu Jardim
          </h1>
          <div className="flex gap-2">
            <Link to="/jogar" className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-full shadow">▶ Jogar</Link>
            <Link to="/" className="bg-white/90 hover:bg-white text-slate-800 font-bold px-4 py-2 rounded-full shadow">← Menu</Link>
          </div>
        </div>

        <div className="bg-white/95 rounded-2xl p-4 md:p-6 shadow-2xl border-4 border-emerald-700/30 mb-6">
          <div className="flex flex-wrap items-center justify-around gap-4 text-center">
            <div>
              <div className="text-3xl font-extrabold text-amber-600">🪙 {coins}</div>
              <div className="text-xs text-slate-600 font-semibold">Moedas</div>
            </div>
            <div>
              <div className="text-3xl font-extrabold text-emerald-700">🌳 {totalTrees}</div>
              <div className="text-xs text-slate-600 font-semibold">Árvores plantadas</div>
            </div>
            <div>
              <div className="text-3xl font-extrabold text-slate-700">{TREE_COST} 🪙</div>
              <div className="text-xs text-slate-600 font-semibold">Custo por árvore</div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          {TIERS.map((tier, tIdx) => {
            const unlocked = tIdx <= activeTierIdx;
            const completed = tierCompleted(tier);
            return (
              <section key={tier.id} className={`rounded-2xl p-4 md:p-5 shadow-xl border-4 ${unlocked ? "bg-white/90 border-emerald-700/30" : "bg-white/40 border-slate-400/40"}`}>
                <header className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <div>
                    <h2 className="text-xl md:text-2xl font-extrabold text-emerald-900 flex items-center gap-2">
                      <span className="text-2xl">{tier.icon}</span> {tier.name}
                      {completed && <span className="text-sm bg-emerald-600 text-white px-2 py-0.5 rounded-full">✓ Completo</span>}
                      {!unlocked && <span className="text-sm bg-slate-500 text-white px-2 py-0.5 rounded-full">🔒 Bloqueado</span>}
                    </h2>
                    <p className="text-sm text-slate-700">{tier.subtitle}</p>
                  </div>
                  {!unlocked && (
                    <p className="text-xs text-slate-600 font-semibold">Conclua a fase anterior para desbloquear</p>
                  )}
                </header>
                <div className={`grid gap-4 md:grid-cols-2 ${!unlocked ? "opacity-50 pointer-events-none" : ""}`}>
                  {tier.spots.map((s) => {
                    const planted = trees[s.id] ?? 0;
                    const full = planted >= s.slots;
                    const canAfford = coins >= TREE_COST;
                    return (
                      <div key={s.id} className={`relative bg-white rounded-2xl p-4 shadow border-2 border-emerald-700/20 overflow-hidden transition-transform ${pulse === s.id ? "scale-[1.02]" : ""}`}>
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-extrabold text-emerald-900 text-lg">{s.emoji} {s.name}</h3>
                          <span className="text-xs font-bold text-slate-600">{planted}/{s.slots}</span>
                        </div>
                        <div className={`relative bg-gradient-to-b ${s.bg} rounded-xl p-3 min-h-[110px] flex flex-wrap gap-2 content-end overflow-hidden`}>
                          <span className="absolute top-1 right-2 text-xl opacity-70">☁️</span>
                          <span className="absolute top-2 left-2 text-lg opacity-80">☀️</span>
                          <div className="absolute bottom-0 left-0 right-0 h-2 bg-emerald-700/50 rounded-b-xl" />
                          {Array.from({ length: s.slots }).map((_, i) => {
                            const grown = i < planted;
                            const isLast = grown && i === planted - 1 && pulse === s.id;
                            return (
                              <span
                                key={i}
                                className={`relative z-10 text-3xl leading-none transition-all duration-500 ${grown ? "translate-y-0 opacity-100" : "translate-y-2 opacity-40"} ${isLast ? "animate-[scale-in_0.5s_ease-out]" : ""}`}
                                style={isLast ? { filter: "drop-shadow(0 0 6px #fde047)" } : undefined}
                              >
                                {grown ? "🌳" : "🟫"}
                              </span>
                            );
                          })}
                          {confetti.length > 0 && pulse === s.id && (
                            <div className="absolute inset-0 pointer-events-none">
                              {confetti.map((p) => (
                                <span
                                  key={p.id}
                                  className="absolute text-xl animate-[fade-out_0.9s_ease-out_forwards]"
                                  style={{ left: p.x, top: p.y, transform: "translate(-50%,-50%)" }}
                                >
                                  {p.emoji}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                        <button
                          onClick={(e) => plant(tIdx, s.id, s.slots, e)}
                          disabled={full || !canAfford || !unlocked}
                          className="mt-3 w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold py-2 rounded-full shadow transition-transform active:scale-95"
                        >
                          {full ? "🎉 Cheio!" : !canAfford ? "🪙 Moedas insuficientes" : `🌱 Plantar (-${TREE_COST} 🪙)`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>

        <p className="text-center text-white/95 mt-6 font-semibold drop-shadow">
          Jogue as fases para ganhar moedas e reflorestar o mundo! 🌍
        </p>
      </div>
    </main>
  );
}