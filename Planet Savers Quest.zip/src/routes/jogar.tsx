import { createFileRoute } from "@tanstack/react-router";
import { SalveOPlanetaGame } from "@/components/SalveOPlanetaGame";

export const Route = createFileRoute("/jogar")({
  head: () => ({
    meta: [
      { title: "Salve o Planeta — Jogar" },
      { name: "description", content: "Jogue agora: recicle, apague queimadas, economize água e plante árvores." },
      { property: "og:title", content: "Salve o Planeta — Jogar" },
      { property: "og:description", content: "Salve o planeta cumprindo as missões ecológicas!" },
    ],
  }),
  component: () => <SalveOPlanetaGame />,
});